<!DOCTYPE html>
<html>
<head>
	<title>Sachetan Password Recovery</title>
</head>
<body>
	<div style="text-align: center;" >
	<img src="image/mail.jpg" alt="sent_mail" align="center">	
	</div>
	<h1 style="color:#e60000; text-align: center; ">A confirmation Msg sent to your email address!
	<br> <br>
	Please Check Your Email.</h1>
</body>
</html>