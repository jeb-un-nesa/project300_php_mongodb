<?php
/*    include("library.php");
    if(chkLogin()){
        header("Location: home.php");
    }*/

 include('dbConnection.php');


?>
<!DOCTYPE html>
<html >

<head>
  <meta charset="UTF-8">
  <title>Sign-Up/Login Form</title>
  <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel="shortcut icon" href="../image/favicon.ico">
    <link rel="icon" href="../image/favicon.ico">

  
      <link rel="stylesheet" href="../CSS/reg.css">

  <!--      <link rel="stylesheet" href="../css1/custom.css">
 -->

  
</head>

<body>