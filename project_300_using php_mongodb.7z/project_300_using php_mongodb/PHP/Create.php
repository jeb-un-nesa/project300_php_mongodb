<?php
include('dbConnection.php');
global $collection;
  $collection =$GLOBALS['db']->selectCollection("user");

if(isset($_GET['source'])){
  $id1=$_GET['source'];
try{
  #$need=array("_id"=> new MongoId($userid));
   $data=$GLOBALS['collection']->findOne(["_id" => new MongoDB\BSON\ObjectID($id1)]);
   //print_r($data);
     //echo $data['firstName'];

}catch(Exception $ex){
  echo $ex->getMessage();

}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Sachetan Create Report</title>
	<!-- Meta tags -->
	<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Meta tags -->
<!-- font-awesome icons -->
   <link rel="stylesheet" href="../css/font-awesome.min.css" />
<!-- //font-awesome icons -->
<!--stylesheets-->
  <!-- <link rel="stylesheet" type="text/css" href="../CSS/Sheader.css"> -->
<link href="../css/style.css" rel='stylesheet' type='text/css' media="all">
<!--//style sheet end here-->
<link href="../css/wickedpicker.css" rel="stylesheet" type='text/css' media="all" /><!--time-->
<link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Muli:300,400,600,600i,700" rel="stylesheet">


</head>
<body>
	<header>
			<div >
				<nav class="navHeader">
					<a class="logo" href="#"><img src="../image/logo.png" width=45px height=40px  /></a>
					<ul>
						<li> <a class="selected" href=<?php "Sheader.php?source=".$id1;?>>Home</a>
					</li>
					<li>
						<a href=<?php echo "Create.php?source=".$id1; ?>>Create Report</a>
					</li>
					<li>
						<a href="#">About</a>
					</li>
					<li>
						<a href=<?php echo "UserProfile.php?source=".$id1; ?>>
							
                        <?php
                           
                           echo $data['firstName'];
                       

                        ?>

						</a>
					</li>
				</ul>
			</nav>
		</div>
	</header>
     <h1 class="header-w3ls">
Create Report</h1>
 <div class="appointment-w3">
    <form action="#" method="post">

         <div class="form-control-w3l">
         
               <input type="text" id="name" name="name" placeholder="Area Name">
          </div>
		  
           
     <div id="ddlViewBy" style="color:#fff;" >
     	<select name="crime" style="color:#fff;height: 30px ; width:537px ; background-color:rgba(249, 249, 249, 0.31); margin-bottom: 10px; padding-left:10px; ">
           <option style="color:#fff;" value="" disabled selected>Report Type</option>
    <option style="color:#000;" value="all">All</option>
    <option style="color:#000;" value="mug">Mugging</option>
    <option style="color:#000;" value="roadacci">Road Accident</option>
    <option style="color:#000;" value="robbery">Robbery</option>
    <option style="color:#000;" value="harass">Sexual Harassment</option>
    <option style="color:#000;" value="theft">Theft</option>
 </select>

</div>
				<div class="form-control-w3l">
					
						<input  id="datepicker1" name="text" type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" placeholder="mm/dd/yyyy" required="">
				</div>
				 <div class="form-control-w3l">
				 
					<input type="text" id="timepicker" name="time" class="timepicker form-control-w3l" placeholder="Time" value="">	
				</div>
<div class="form-control-w3l">
 <textarea id="message" name="text" placeholder="Description of incident..."></textarea>
 </div>
 <!-- <div class="form-control-w3l">	
			
				<input type="text" id="orgn" name="phone number" placeholder="Phone Number" title="Please enter your Phone Number" required=""> -->


					<!-- ================ -->
 <div id="ddlViewBy" style="color: #fff" >
     	<select style=" color:#fff; height: 30px ; width:537px ; background-color:rgba(249, 249, 249, 0.31); margin-bottom: 10px; padding-left:10px;">
           <option style="color:#fff;" value="" disabled selected>Severity</option>
    <option style="color: #000"  value="one">1</option>
    <option style="color: #000"  value="two">2</option>
    <option style="color: #000" value="three">3</option>
    <option style="color: #000" value="four">4</option>
    <option style="color: #000" value="five">5</option>
 </select>

</div>
					<!-- ================= -->
		  <!--  </div> -->
 <input  type="submit" value="Submit" >
</form>
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
            <script type="text/javascript" src="../JS/Sheader.js"></script>
   </div>
   
    
 
		<!-- js -->
		<script type="text/javascript" src="../js/Sheader.js"></script>
  <script type='text/javascript' src='../js/jquery-2.2.3.min.js'></script>
<!-- //js -->
<!-- Calendar -->
				<link rel="stylesheet" href="../css/jquery-ui.css" />
				<script src="../js/jquery-ui.js"></script>
				  <script>
						  $(function() {
							$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
						  });
				  </script>
				  <script>var e = document.getElementById("ddlViewBy");
var strUser = e.options[e.selectedIndex].value;</script>
			<!-- //Calendar -->
			<!-- Time -->
			<script type="text/javascript" src="../js/wickedpicker.js"></script>
			<script type="text/javascript">
				$('.timepicker').wickedpicker({twentyFour: false});
			</script>
		<!-- // Time -->

</body>
</html>