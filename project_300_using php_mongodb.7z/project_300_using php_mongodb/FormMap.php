<?php

// global $collection;
//   $collection =$GLOBALS['db']->selectCollection("user");
//   global $collectionReport;
//   $collectionReport=$GLOBALS['db']->selectCollection("report");

$lat=(isset($_GET['lat']))?$_GET['lat']:'';
$long=(isset($_GET['long']))?$_GET['long']:'';
 var_dump( $lat) ;
 echo $long;
 echo "jemi";

//do whatever you want

?>