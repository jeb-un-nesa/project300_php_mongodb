
<!DOCTYPE html>
<html>
<head>
    <title>WelCome to Sachetan</title>
    <link rel="stylesheet" type="text/css" href="css/Welcome.css">
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1,h2,h3,h4,h5,h6 {
    font-family: "Playfair Display";
    letter-spacing: 5px;
}
</style>
<body>


</head>
<body>
<header>
    <div>
      <nav class="navHeader">
        <a class="logo" href="#"><img src="image/logo.png" width=45px height=40px  /></a>
       <ul>
          <li> <a  href=<?php "Sheader.php?source=".$id1;?>>Home</a>
          </li>
          <li>
<!-- CREATE REPORT IN NAVBAR -->
          </li>
          <li>
            <a class="selected" href="About.php">About</a>
          </li>
          <li>
           <a href=<?php echo "UserProfile.php?source=".$id1; ?>>

            <?php

            echo $data['firstName'];


            ?>

          </a>
        </li>
      </ul>
    </nav>
  </div>
</header>
<div> <img src="image/image1.jpg" hight="60%" width="90%"></div>
<div class="w3-row w3-padding-64" id="about">
    <div class="w3-col m6 w3-padding-large w3-hide-small">
     <img src="image/WelCrime.jpg" class="w3-round w3-image w3-opacity-min" alt="Table Setting" width="600" height="800">
    </div>

    <div>
      <h1 class="w3-center">About Sachetan</h1><br>
      <p class="w3-large" style="padding-bottom: 10px">In this era of globalization, we can not get rid of some social problems like mugging, robbery,road-accident, theft, sexual-harassment. But may be we can aware ourselves as well as all other people. This website can be a wonderful platform for our purposes. </p>
      <p class="w3-large "> <span class="w3-tag w3-light-grey">First of all</span>, you can see the map focused to your <span class="w3-tag w3-light-grey">current position</span> along       
   with neighborhood areas. You can see some green, yellow and red     
   points which indicate the danger points means the area where different     
   negative incident occurs.
<br>
You can redraw the points based on incident type and the data  source.     
   There are 2 data sources. One is <span class="w3-tag w3-light-grey">online newspapers</span>  and  
   another is <span class="w3-tag w3-light-grey">website users</span>. Users can <span class="w3-tag w3-light-grey">create a report </span>about incident which will be shared to other Users. Thus we can help each other.
<br>
   Another feature is, you can see the <span class="w3-tag w3-light-grey">path of a destination from Your         
   current position</span>. To indicate your destination point, you have to simply     
   touch to the point from the map.So a route is  drawn from your current   
   position to your destination. You can see some red lines in your route if     
   there is any danger point exists. So one can easily avoid a specific place    
   to choose a safest path.
 </p>
    </div>
  </div>

</body>
</html>